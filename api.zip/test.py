import cv2
import numpy as np
import joblib
from skimage.feature import hog
from collections import Counter

# --- Load Trained Model ---
model = joblib.load('svm_motor_fault_model.pkl')  # make sure this file exists

# --- Frame Loader ---
def load_frames(video_path, max_frames=150):
    cap = cv2.VideoCapture(video_path)
    frames = []
    while cap.isOpened() and len(frames) < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        frame = cv2.resize(frame, (128, 128))  # match training
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        frames.append(gray)
    cap.release()
    return frames

# --- Feature Extractor ---
def extract_features(frames):
    features = []
    for f in frames:
        f = cv2.GaussianBlur(f, (3, 3), 0)
        hog_feat = hog(f, pixels_per_cell=(16, 16), cells_per_block=(1, 1), feature_vector=True)
        features.append(hog_feat)
    return np.array(features)

# --- Run Prediction ---
video_path = "NormalTest.mp4"  # Replace with your local test video
frames = load_frames(video_path)

if len(frames) == 0:
    print("❌ No frames extracted from video.")
else:
    features = extract_features(frames)

    if features.shape[1] != 576:
        print(f"❌ Feature size mismatch: {features.shape[1]} features per frame (expected 576)")
    else:
        preds = model.predict(features)
        print("✅ Prediction counts:", Counter(preds))
        majority_class = Counter(preds).most_common(1)[0][0]
        print("🧠 Final result:", "Normal" if majority_class == 0 else "Faulty")
