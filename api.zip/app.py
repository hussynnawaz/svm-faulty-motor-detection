import os
import cv2
import numpy as np
import joblib
import json
from flask import Flask, request, jsonify
from skimage.feature import hog

# --- Flask App ---
app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
RESULTS_FOLDER = 'results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

# --- Load Trained SVM Model ---
model = joblib.load('models/model2.pkl')  # trained with 128x128, HOG(16,16),(1,1)

# --- Frame Processing ---
def load_frames_from_video(video_path, max_frames=150):
    cap = cv2.VideoCapture(video_path)
    frames = []
    while cap.isOpened() and len(frames) < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        frame = cv2.resize(frame, (128, 128))  # MATCH TRAINING: resized to 128x128
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        frames.append(gray)
    cap.release()
    return frames

def zoom_frame(img, factor=1.2):
    h, w = img.shape
    zh, zw = int(h*factor), int(w*factor)
    zoomed = cv2.resize(img, (zw, zh))
    y0, x0 = (zh-h)//2, (zw-w)//2
    return zoomed[y0:y0+h, x0:x0+w]

def extract_features(frames):
    features = []
    for f in frames:
        f = cv2.GaussianBlur(f, (3,3), 0)
        f = zoom_frame(f, 1.2)        # ← zoom here
        hog_feat = hog(f,
                       pixels_per_cell=(16,16),
                       cells_per_block=(1,1),
                       feature_vector=True)
        features.append(hog_feat)
    return np.array(features)

# --- API Route ---
@app.route('/classify', methods=['POST'])
def classify_video():
    if 'video' not in request.files:
        return jsonify({'error': 'No video file provided'}), 400

    video_file = request.files['video']
    filename = os.path.join(UPLOAD_FOLDER, video_file.filename)
    video_file.save(filename)

    try:
        frames = load_frames_from_video(filename)
        if len(frames) == 0:
            return jsonify({'error': 'Could not extract frames from video'}), 400

        features = extract_features(frames)

        if features.shape[1] != 576:
            return jsonify({'error': f'Feature size mismatch. Got {features.shape[1]}, expected 576'}), 400

        predictions = model.predict(features)
        probs = model.predict_proba(features)

        # Majority vote
        predicted_class = int(np.round(np.mean(predictions)))
        label = 'Normal' if predicted_class == 0 else 'Faulty'
        confidence = float(np.mean(probs[:, predicted_class]))

        result_data = {
            'result': label,
            'confidence': round(confidence, 3),
            'frames_analyzed': len(frames),
            'video_name': video_file.filename
        }

        # --- Save result as JSON ---
        json_filename = os.path.splitext(video_file.filename)[0] + '.json'
        json_path = os.path.join(RESULTS_FOLDER, json_filename)
        with open(json_path, 'w') as f:
            json.dump(result_data, f, indent=4)

        return jsonify(result_data)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

# --- Run the app ---
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
